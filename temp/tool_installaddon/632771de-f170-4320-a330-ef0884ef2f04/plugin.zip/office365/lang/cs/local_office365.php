<?php
$string['pluginname'] = 'Integrace Microsoft 365';
