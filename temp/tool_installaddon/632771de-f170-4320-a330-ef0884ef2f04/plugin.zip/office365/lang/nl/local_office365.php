<?php
$string['pluginname'] = 'Integratie met Microsoft 365';
