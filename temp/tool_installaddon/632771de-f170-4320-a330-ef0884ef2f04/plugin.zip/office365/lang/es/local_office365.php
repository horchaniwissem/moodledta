<?php
$string['pluginname'] = 'Integración de Microsoft 365';
