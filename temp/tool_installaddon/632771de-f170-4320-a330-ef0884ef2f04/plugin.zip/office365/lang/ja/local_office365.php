<?php
$string['pluginname'] = 'Microsoft 365の統合';
