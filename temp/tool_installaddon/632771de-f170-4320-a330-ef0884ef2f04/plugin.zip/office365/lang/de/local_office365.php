<?php
$string['pluginname'] = 'Microsoft 365-Integration';
