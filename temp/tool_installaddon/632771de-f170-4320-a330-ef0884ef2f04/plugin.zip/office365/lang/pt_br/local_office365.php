<?php
$string['pluginname'] = 'Integração ao Microsoft 365';
