<?php
$string['pluginname'] = 'Integrazione Microsoft 365';
