<?php
$string['pluginname'] = 'Intégration d\'Microsoft 365';
