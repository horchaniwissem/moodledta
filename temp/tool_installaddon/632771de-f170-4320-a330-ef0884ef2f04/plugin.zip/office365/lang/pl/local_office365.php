<?php
$string['pluginname'] = 'Integracja pakietu Microsoft 365';
